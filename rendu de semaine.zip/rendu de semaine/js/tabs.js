let tabsItems = document.querySelectorAll("ul li")
tabsItems.forEach(function(item) {
    item.addEventListener("click", function() {

        document.querySelector("li.tab-active").classList.remove("tab-active")
        item.classList.add("tab-active")
        document.querySelector("div.active").classList.remove("active")
        if (item.classList.contains('tab-layton')) {
            document.querySelector('.layton').classList.add('active')
        } else if (item.classList.contains('tab-goldensun')) {
            document.querySelector('.goldensun').classList.add('active')
        } else if (item.classList.contains('tab-subnautica')) {
            document.querySelector('.subnautica').classList.add('active')
        }
    })
});